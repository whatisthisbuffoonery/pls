/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 15:42:50 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 16:30:23 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int	main(int argc, char **argv)
{
	t_puzzle	puzzle;

	if (argc != 2)
	{
		ft_putstr_error("Error: No argument\n");
		return (1);
	}
	if (!ft_init_puzzle(&puzzle, argv[1]))
	{
		ft_putstr_error("Error: Invalid Clue numbers, cannot initialize\n");
		return (1);
	}
	if (!ft_solve(&puzzle))
	{
		ft_putstr_error("Error: Unable to Solve puzzle\n");
		return (1);
	}
	ft_display_solution(&puzzle);
	return (0);
}
