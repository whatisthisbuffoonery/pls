/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_solve.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 14:09:13 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 15:35:54 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int	ft_solve(t_puzzle *puzzle)
{
	return (ft_solve_recursive(puzzle, 0));
}

int	ft_solve_recursive(t_puzzle *puzzle, int pos)
{
	int	row;
	int	col;
	int	num;

	if (pos >= N * N)
		return (1);
	row = pos / N;
	col = pos % N;
	num = 1;
	while (num <= N)
	{
		puzzle->grid[row][col] = num;
		if (ft_is_placement_valid(puzzle, row, col, num))
		{
			if (ft_solve_recursive(puzzle, pos + 1))
				return (1);
		}
		num++;
	}
	puzzle->grid[row][col] = 0;
	return (0);
}
