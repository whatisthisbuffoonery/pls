/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   grid_check.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dthoo <dthoo@student.42singapore.sg>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 23:07:15 by dthoo             #+#    #+#             */
/*   Updated: 2025/08/03 23:07:20 by dthoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	count_left_to_right(int grid[4][4], int row)
{
	int	count;
	int	max_height;
	int	col;

	count = 0;
	max_height = 0;
	col = 0;
	while (col < 4)
	{
		if (grid[row][col] > max_height)
		{
			max_height = grid[row][col];
			count++;
		}
		col++;
	}
	return (count);
}

int	count_right_to_left(int grid[4][4], int row)
{
	int	count;
	int	max_height;
	int	col;

	count = 0;
	max_height = 0;
	col = 3;
	while (col >= 0)
	{
		if (grid[row][col] > max_height)
		{
			max_height = grid[row][col];
			count++;
		}
		col--;
	}
	return (count);
}

int	count_top_to_bottom(int grid[4][4], int col)
{
	int	count;
	int	max_height;
	int	row;

	count = 0;
	max_height = 0;
	row = 0;
	while (row < 4)
	{
		if (grid[row][col] > max_height)
		{
			max_height = grid[row][col];
			count++;
		}
		row++;
	}
	return (count);
}

int	count_bottom_to_top(int grid[4][4], int col)
{
	int	count;
	int	max_height;
	int	row;

	count = 0;
	max_height = 0;
	row = 3;
	while (row >= 0)
	{
		if (grid[row][col] > max_height)
		{
			max_height = grid[row][col];
			count++;
		}
		row--;
	}
	return (count);
}

int	check_all_constraints(int grid[4][4], int constraints[4][4])
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (count_top_to_bottom(grid, i) != constraints[0][i])
			return (0);
		if (count_bottom_to_top(grid, i) != constraints[1][i])
			return (0);
		if (count_left_to_right(grid, i) != constraints[2][i])
			return (0);
		if (count_right_to_left(grid, i) != constraints[3][i])
			return (0);
		i++;
	}
	return (1);
}
