/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillup.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dthoo <dthoo@student.42singapore.sg>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 23:06:45 by dthoo             #+#    #+#             */
/*   Updated: 2025/08/03 23:06:46 by dthoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print(int arr[4][4]);
int		check_all_constraints(int grid[4][4], int constraints[4][4]);
int		count_left_to_right(int grid[4][4], int row);
int		count_right_to_left(int grid[4][4], int row);
int		count_top_to_bottom(int grid[4][4], int col);
int		count_bottom_to_top(int grid[4][4], int col);

int	is_valid_number(int grid[4][4], int row, int col, int value)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (i != col && grid[row][i] == value)
			return (0);
		if (i != row && grid[i][col] == value)
			return (0);
		i++;
	}
	return (1);
}

int	is_complete_line(int grid[4][4], int row, int col, int is_row)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (is_row && grid[row][i] == 0)
			return (0);
		if (!is_row && grid[i][col] == 0)
			return (0);
		i++;
	}
	return (1);
}

int	check_partial(int grid[4][4], int constraints[4][4], int row, int col)
{
	if (is_complete_line(grid, row, col, 1))
	{
		if (count_left_to_right(grid, row) != constraints[2][row])
			return (0);
		if (count_right_to_left(grid, row) != constraints[3][row])
			return (0);
	}
	if (is_complete_line(grid, row, col, 0))
	{
		if (count_top_to_bottom(grid, col) != constraints[0][col])
			return (0);
		if (count_bottom_to_top(grid, col) != constraints[1][col])
			return (0);
	}
	return (1);
}

int	solve_puzzle(int grid[4][4], int constraints[4][4], int pos)
{
	int	row;
	int	col;
	int	value;

	if (pos == 16)
		return (check_all_constraints(grid, constraints));
	row = pos / 4;
	col = pos % 4;
	value = 1;
	while (value <= 4)
	{
		if (is_valid_number(grid, row, col, value))
		{
			grid[row][col] = value;
			if (check_partial(grid, constraints, row, col))
				if (solve_puzzle(grid, constraints, pos + 1))
					return (1);
			grid[row][col] = 0;
		}
		value++;
	}
	return (0);
}

void	solve(int constraints[4][4])
{
	int	grid[4][4];
	int	i;
	int	j;

	i = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			grid[i][j] = 0;
			j++;
		}
		i++;
	}
	if (solve_puzzle(grid, constraints, 0))
		print(grid);
	else
		write(1, "Error\n", 6);
}
