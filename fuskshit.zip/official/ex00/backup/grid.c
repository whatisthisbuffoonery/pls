/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   grid.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dthoo <dthoo@student.42singapore.sg>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 23:07:54 by dthoo             #+#    #+#             */
/*   Updated: 2025/08/03 23:07:56 by dthoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	count_left_to_right(int grid[4][4], int row);
int	count_right_to_left(int grid[4][4], int row);
int	count_top_to_bottom(int grid[4][4], int col);
int	count_bottom_to_top(int grid[4][4], int col);

void	place_edge_fours(int grid[4][4], int constraints[4][4], int i)
{
	if (constraints[0][i] == 1)
		grid[0][i] = 4;
	if (constraints[1][i] == 1)
		grid[3][i] = 4;
	if (constraints[2][i] == 1)
		grid[i][0] = 4;
	if (constraints[3][i] == 1)
		grid[i][3] = 4;
}

void	place_ascending_col(int grid[4][4], int col, int top_to_bottom)
{
	if (top_to_bottom)
	{
		grid[0][col] = 1;
		grid[1][col] = 2;
		grid[2][col] = 3;
		grid[3][col] = 4;
	}
	else
	{
		grid[3][col] = 1;
		grid[2][col] = 2;
		grid[1][col] = 3;
		grid[0][col] = 4;
	}
}

void	place_ascending_row(int grid[4][4], int row, int left_to_right)
{
	if (left_to_right)
	{
		grid[row][0] = 1;
		grid[row][1] = 2;
		grid[row][2] = 3;
		grid[row][3] = 4;
	}
	else
	{
		grid[row][3] = 1;
		grid[row][2] = 2;
		grid[row][1] = 3;
		grid[row][0] = 4;
	}
}

void	place_ascending_sequences(int grid[4][4], int constraints[4][4], int i)
{
	if (constraints[0][i] == 4)
		place_ascending_col(grid, i, 1);
	if (constraints[1][i] == 4)
		place_ascending_col(grid, i, 0);
	if (constraints[2][i] == 4)
		place_ascending_row(grid, i, 1);
	if (constraints[3][i] == 4)
		place_ascending_row(grid, i, 0);
}

void	init_obvious_values(int grid[4][4], int constraints[4][4])
{
	int	i;

	i = 0;
	while (i < 4)
	{
		place_edge_fours(grid, constraints, i);
		place_ascending_sequences(grid, constraints, i);
		i++;
	}
}
