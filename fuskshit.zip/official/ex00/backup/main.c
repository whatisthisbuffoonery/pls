/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dthoo <dthoo@student.42singapore.sg>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 23:05:35 by dthoo             #+#    #+#             */
/*   Updated: 2025/08/03 23:05:45 by dthoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	solve(int arr[4][4]);

int	input_to_array(char *str, int arr[4][4])
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	while (str[i] != '\0' && count < 16)
	{
		if (str[i] >= '1' && str[i] <= '4')
		{
			arr[count / 4][count % 4] = str[i] - '0';
			count++;
		}
		else if (str[i] != ' ')
		{
			write(1, "Error\n", 6);
			return (1);
		}
		i++;
	}
	if (count != 16)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	return (0);
}

int	main(int argc, char **argv)
{
	int	arr[4][4];

	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	if (input_to_array(argv[1], arr) == 1)
		return (0);
	solve(arr);
	return (0);
}
