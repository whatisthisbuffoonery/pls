/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_validate_2.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 15:33:04 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 16:31:12 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

static int	check_row_clues(t_puzzle *puzzle, int row)
{
	if (ft_check_visibility(puzzle->grid[row], 0) != puzzle->clues_left[row])
	{
		return (0);
	}
	if (ft_check_visibility(puzzle->grid[row], 1) != puzzle->clues_right[row])
	{
		return (0);
	}
	return (1);
}

static int	check_col_clues(t_puzzle *puzzle, int col)
{
	int	temp_col[N];
	int	i;

	i = 0;
	while (i < N)
	{
		temp_col[i] = puzzle->grid[i][col];
		i++;
	}
	if (ft_check_visibility(temp_col, 0) != puzzle->clues_top[col])
	{
		return (0);
	}
	if (ft_check_visibility(temp_col, 1) != puzzle->clues_bottom[col])
	{
		return (0);
	}
	return (1);
}

int	ft_is_placement_valid(t_puzzle *puzzle, int row, int col, int num)
{
	if (!check_row_uniqueness(puzzle, row, col, num))
	{
		return (0);
	}
	if (!check_col_uniqueness(puzzle, row, col, num))
	{
		return (0);
	}
	if (col == N - 1)
	{
		if (!check_row_clues(puzzle, row))
		{
			return (0);
		}
	}
	if (row == N - 1)
	{
		if (!check_col_clues(puzzle, col))
		{
			return (0);
		}
	}
	return (1);
}
