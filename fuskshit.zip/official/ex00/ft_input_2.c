/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_input_2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 14:08:19 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 19:53:33 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"
#include <unistd.h>

int	ft_parse_clues(int *clues, char **ptr, int count)
{
	int	i;
	int	num;

	i = 0;
	while (i < count)
	{
		num = parse_number(ptr);
		if (num == 0)
			return (0);
		clues[i] = num;
		i++;
	}
	return (1);
}

static int	ft_parse_and_check_clues(int *clues_arr, char **ptr,
		char *error_msg)
{
	if (!ft_parse_clues(clues_arr, ptr, N))
	{
		ft_putstr_error(error_msg);
		return (0);
	}
	return (1);
}

int	ft_read_all_clues(t_puzzle *puzzle, char *ptr)
{
	if (!ft_parse_and_check_clues(puzzle->clues_top, &ptr,
			"Error: Top Clues are invalid\n"))
		return (0);
	if (!ft_parse_and_check_clues(puzzle->clues_bottom, &ptr,
			"Error: Bottom Clues are invalid\n"))
		return (0);
	if (!ft_parse_and_check_clues(puzzle->clues_left, &ptr,
			"Error: left Clues are invalid\n"))
		return (0);
	if (!ft_parse_and_check_clues(puzzle->clues_right, &ptr,
			"Error: Right Clues are invalid\n"))
		return (0);
	while (*ptr == ' ')
	{
		ptr++;
	}
	if (*ptr != '\0')
	{
		return (0);
	}
	return (1);
}

int	ft_init_puzzle(t_puzzle *puzzle, char *clue_str)
{
	char	*ptr;

	ft_init_grid(puzzle);
	ptr = clue_str;
	if (!ft_read_all_clues(puzzle, ptr))
		return (0);
	return (ft_validate_clues(puzzle));
}
