/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_input.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 13:12:58 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 19:51:40 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int	parse_number(char **str)
{
	int	num;

	while (**str == ' ' || (**str >= 9 && **str <= 13))
	{
		(*str)++;
	}
	if (!(**str >= '0' && **str <= '9'))
	{
		return (0);
	}
	num = 0;
	while (**str >= '0' && **str <= '9')
	{
		num = num * 10 + (**str - '0');
		(*str)++;
	}
	return (num);
}

int	ft_validate_clues(t_puzzle *puzzle)
{
	int	i;

	i = 0;
	while (i < N)
	{
		if (puzzle->clues_left[i] + puzzle->clues_right[i] < 3
			|| puzzle->clues_left[i] + puzzle->clues_right[i] > N + 1)
			return (0);
		if (puzzle->clues_top[i] + puzzle->clues_bottom[i] < 3
			|| puzzle->clues_top[i] + puzzle->clues_bottom[i] > N + 1)
			return (0);
		if ((puzzle->clues_left[i] == N && puzzle->clues_right[i] != 1)
			|| (puzzle->clues_right[i] == N && puzzle->clues_left[i] != 1))
			return (0);
		if ((puzzle->clues_top[i] == N && puzzle->clues_bottom[i] != 1)
			|| (puzzle->clues_bottom[i] == N && puzzle->clues_top[i] != 1))
			return (0);
		if (puzzle->clues_left[i] < 1 || puzzle->clues_left[i] > N
			|| puzzle->clues_right[i] < 1 || puzzle->clues_right[i] > N
			|| puzzle->clues_top[i] < 1 || puzzle->clues_top[i] > N
			|| puzzle->clues_bottom[i] < 1 || puzzle->clues_bottom[i] > N)
			return (0);
		i++;
	}
	return (1);
}

void	ft_init_grid(t_puzzle *puzzle)
{
	int	r;
	int	c;

	r = 0;
	while (r < N)
	{
		c = 0;
		while (c < N)
		{
			puzzle->grid[r][c] = 0;
			c++;
		}
		r++;
	}
}
