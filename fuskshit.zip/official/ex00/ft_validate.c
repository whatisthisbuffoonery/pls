/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_validate.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 14:54:50 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 15:37:49 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int	ft_check_visibility(const int *line, int reversed)
{
	int	count;
	int	max_height;
	int	index;
	int	i;

	count = 0;
	max_height = 0;
	index = 0;
	i = 0;
	while (i < N)
	{
		if (reversed)
		{
			index = N - 1 - i;
		}
		else
			index = i;
		if (line[index] > max_height)
		{
			max_height = line[index];
			count++;
		}
		++i;
	}
	return (count);
}

int	check_row_uniqueness(t_puzzle *puzzle, int row, int col, int num)
{
	int	c;

	c = 0;
	while (c < N)
	{
		if (c != col && puzzle->grid[row][c] == num)
		{
			return (0);
		}
		c++;
	}
	return (1);
}

int	check_col_uniqueness(t_puzzle *puzzle, int row, int col, int num)
{
	int	r;

	r = 0;
	while (r < N)
	{
		if (r != row && puzzle->grid[r][col] == num)
		{
			return (0);
		}
		r++;
	}
	return (1);
}
