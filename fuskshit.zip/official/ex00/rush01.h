/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dthoo <dthoo@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 13:07:03 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/04 17:46:47 by dthoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH01_H
# define RUSH01_H
# define N 7

typedef struct s_puzzle
{
	int	grid[N][N];
	int	clues_top[N];
	int	clues_bottom[N];
	int	clues_left[N];
	int	clues_right[N];
}	t_puzzle;

int		ft_init_puzzle(t_puzzle *puzzle, char *clue_str);
int		ft_solve(t_puzzle *puzzle);
void	ft_display_solution(t_puzzle *puzzle);
void	ft_putstr_error(char *str);
int		ft_is_placement_valid(t_puzzle *puzzle, int row, int col, int num);
int		ft_check_visibility(const int *line, int reversed);
int		ft_validate_clues(t_puzzle *puzzle);
int		parse_number(char **str);
void	ft_init_grid(t_puzzle *puzzle);
int		ft_solve_recursive(t_puzzle *puzzle, int pos);
int		check_row_uniqueness(t_puzzle *puzzle, int row, int col, int num);
int		check_col_uniqueness(t_puzzle *puzzle, int row, int col, int num);

#endif
/*
int	grid[N][N];
int	clues_top[N];
int	clues_bottom[N];
int	clues_left[N];
int	clues_right[N];
int	(*pointer_arr)[8]; // N + N grid, we assume 4 + 4 = 8 for now

(*pointer_arr)[0] = grid[0];
(*pointer_arr)[1] = grid[1];
(*pointer_arr)[2] = grid[2];
(*pointer_arr)[3] = grid[3];
...
...
(*pointer_arr)[7] = clues_right;


-------------------this:
void	ft_init_grid(t_puzzle *puzzle);
-------------------becomes:
void	ft_init_grid((*pointer_arr)[8]);

void	ft_init_grid(t_puzzle *puzzle)
{
	int	r;
	int	c;
				//puzzle_arr[r][c], where r < N
	r = 0;					|
	while (r < N) 				|
	{					|
		c = 0;				|
		while (c < N)			|
		{				|
			puzzle->grid[r][c] = 0; <
			c++;
		}
		r++;
}



	}
}
*/
