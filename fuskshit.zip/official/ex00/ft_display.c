/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkai-yua <lkai-yua@student.42singapore.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 12:51:05 by lkai-yua          #+#    #+#             */
/*   Updated: 2025/08/03 15:49:04 by lkai-yua         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"
#include <unistd.h>

void	ft_putstr_error(char *str)
{
	while (*str)
	{
		write(2, str, 1);
		str++;
	}
}

void	ft_display_solution(t_puzzle *puzzle)
{
	int	row;
	int	column;
	int	ch;

	row = 0;
	while (row < N)
	{
		column = 0;
		while (column < N)
		{
			ch = puzzle->grid[row][column] + '0';
			write(1, &ch, 1);
			if (column < N - 1)
				write(1, " ", 1);
			column++;
		}
		write(1, "\n", 1);
		row++;
	}
}
